# CardputerZero FT8 RX 0.2.0

Диагностическая receive-only версия. Передача, CAT и PTT отсутствуют.

## Запуск

Проверка RPi USB Audio:

```bash
cardputerzero-ft8-rx --input-mode rpi --sync-time
```

Проверка через микрофон:

```bash
cardputerzero-ft8-rx --input-mode microphone --sync-time
```

Если микрофон не выбран автоматически:

```bash
arecord -l
cardputerzero-ft8-rx --input-mode microphone --device 1
```

## Диагностика

Каждые 15 секунд записывается WAV-фрагмент в `~/.cardputerzero-ft8/diagnostics/`. Уровни RMS, peak, ошибки ALSA и сведения о выбранной карте записываются в `~/.cardputerzero-ft8/diagnostic.log`. Декоды остаются в `~/.cardputerzero-ft8/decodes.log`.

Для работы без записи:

```bash
cardputerzero-ft8-rx --input-mode microphone --no-record
```

На экране показываются UTC, смещение относительно NTP, выбранный источник и уровень сигнала. `--sync-time` включает системную NTP-синхронизацию; если у приложения нет прав администратора, оно сообщит об этом и не изменит часы.
