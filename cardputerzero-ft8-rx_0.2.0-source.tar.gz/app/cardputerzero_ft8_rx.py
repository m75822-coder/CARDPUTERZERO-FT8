#!/usr/bin/env python3
"""CardputerZero FT8 RX diagnostic receiver, version 0.2.0."""
import argparse
import curses
import datetime
import json
import os
import queue
import signal
import socket
import struct
import subprocess
import sys
import time

APP = "CardputerZero FT8 RX"
VERSION = "0.2.0"
DATA_DIR = os.path.expanduser("~/.cardputerzero-ft8")
LOG_FILE = os.path.join(DATA_DIR, "decodes.log")
DIAG_DIR = os.path.join(DATA_DIR, "diagnostics")
sys.path.insert(0, "/opt/cardputerzero-ft8-rx")
from PyFT8.receiver import Receiver  # noqa: E402


def append_log(text):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(os.path.join(DATA_DIR, "diagnostic.log"), "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now().isoformat(timespec='seconds')} {text}\n")


def ntp_offset(server="pool.ntp.org"):
    """Return local-clock offset in seconds using one NTP request."""
    packet = b"\x1b" + 47 * b"\0"
    t0 = time.time()
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(3.0)
        sock.sendto(packet, (server, 123))
        data, _ = sock.recvfrom(512)
    t3 = time.time()
    if len(data) < 48:
        raise RuntimeError("short NTP reply")
    t1 = struct.unpack("!12I", data[:48])[8] + struct.unpack("!12I", data[:48])[9] / 2**32
    t2 = struct.unpack("!12I", data[:48])[10] + struct.unpack("!12I", data[:48])[11] / 2**32
    ntp_epoch = 2208988800
    t1 -= ntp_epoch
    t2 -= ntp_epoch
    return ((t1 - t0) + (t2 - t3)) / 2


def time_check(server):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    try:
        offset = ntp_offset(server)
        return f"UTC={now} NTP offset={offset:+.3f}s server={server}", offset
    except Exception as exc:
        return f"UTC={now} NTP check failed: {exc}", None


def sync_time(server):
    lines = []
    for cmd in (["timedatectl", "set-ntp", "true"], ["sudo", "-n", "timedatectl", "set-ntp", "true"]):
        try:
            result = subprocess.run(cmd, text=True, capture_output=True, timeout=5)
            if result.returncode == 0:
                lines.append("NTP synchronization enabled: " + " ".join(cmd))
                return lines
            lines.append("sync command failed: " + (result.stderr or result.stdout).strip())
        except Exception as exc:
            lines.append("sync command error: " + str(exc))
    lines.append("Time was not changed; run timedatectl manually with administrator rights")
    return lines


class DisplayReceiver(Receiver):
    def __init__(self, events, args):
        self.events = events
        super().__init__(max_freq=3000, output_type="print", input_keywords=None,
                         input_mode=args.input_mode, device_hint=args.device,
                         diagnostics_dir=None if args.no_record else args.diagnostics_dir,
                         diagnostic_seconds=args.record_seconds,
                         log_callback=self._audio_log)

    def _audio_log(self, text):
        append_log(text)
        try:
            self.events.put_nowait({"mtype": "diagnostic", "info": text})
        except queue.Full:
            pass

    def send_output(self, msg_dict, noprint=False):
        if msg_dict.get("mtype") == "waterfall":
            return
        try:
            self.events.put_nowait(msg_dict)
        except queue.Full:
            pass


def save_decode(msg):
    os.makedirs(DATA_DIR, exist_ok=True)
    now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(msg.get("t_decode", time.time())))
    tup = msg.get("msg_tuple")
    text = " ".join(str(x) for x in tup) if tup else str(msg)
    line = f"{now} {msg.get('their_snr','?'):>3}dB {msg.get('fHz','?'):>7}Hz {text}\n"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line)
    return line.rstrip()


def main_screen(stdscr, args):
    try:
        curses.curs_set(0)
    except curses.error:
        pass
    stdscr.nodelay(True)
    stdscr.timeout(200)
    events = queue.Queue(maxsize=400)
    lines = []
    status = "Starting..."
    start = time.time()
    receiver = None
    clock_line, _ = time_check(args.ntp_server)
    append_log(clock_line)
    if args.sync_time:
        for line in sync_time(args.ntp_server):
            append_log(line)
            lines.append(line)
    try:
        receiver = DisplayReceiver(events, args)
        if not receiver.running:
            status = "Audio input not found"
        else:
            status = f"RX active: {args.input_mode} / 12000 Hz / FT8"
    except Exception as exc:
        status = "Audio error: " + str(exc)[:70]
        append_log(status)
    while True:
        try:
            key = stdscr.getch()
            if key in (ord("q"), ord("Q"), 27):
                break
        except curses.error:
            pass
        while True:
            try:
                msg = events.get_nowait()
            except queue.Empty:
                break
            typ = msg.get("mtype")
            if typ == "decode":
                lines.append(save_decode(msg))
            elif typ == "rollover":
                status = "RX active | new 15-second cycle"
            elif typ == "test_info":
                info = msg.get("info", "")
                if "Search finished" in info:
                    status = "RX active | " + info[:55]
            elif typ == "info":
                status = str(msg.get("info", status))[:75]
            elif typ == "diagnostic":
                lines.append("[diag] " + str(msg.get("info", "")))
            if len(lines) > 80:
                lines = lines[-80:]
        h, w = stdscr.getmaxyx()
        stdscr.erase()
        title = f" {APP} v{VERSION} | RECEIVE ONLY | q: quit "
        stdscr.addnstr(0, 0, title.ljust(w), w - 1, curses.A_REVERSE)
        elapsed = int(time.time() - start)
        level = getattr(getattr(receiver, "audio_in", None), "last_level", {}) if receiver else {}
        level_text = "no level"
        if level:
            level_text = f"RMS {level.get('rms', 0):.0f} peak {level.get('peak', 0):.0f} dBFS {level.get('dbfs', -99):+.1f}"
        stdscr.addnstr(1, 0, f"{status} [{elapsed}s] {level_text}"[:w-1], w-1)
        stdscr.addnstr(2, 0, f"Input: {args.input_mode}  Record: {'off' if args.no_record else args.record_seconds.__str__() + 's WAV'}  Clock: {clock_line}"[:w-1], w-1)
        stdscr.addnstr(3, 0, "Time                 SNR     Frequency   Message / diagnostic"[:w-1], w-1, curses.A_BOLD)
        visible = max(1, h - 6)
        for row, line in enumerate(lines[-visible:], 4):
            stdscr.addnstr(row, 0, line[:w-1], w-1)
        if h >= 2:
            stdscr.addnstr(h-1, 0, f"Log: {LOG_FILE}  WAV: {args.diagnostics_dir}"[:w-1], w-1, curses.A_DIM)
        stdscr.refresh()
    if receiver is not None:
        receiver.running = False
        try:
            receiver.audio_in.close()
        except Exception:
            pass


def parse_args():
    parser = argparse.ArgumentParser(description="Receive-only FT8 diagnostic monitor")
    parser.add_argument("--input-mode", choices=("auto", "rpi", "microphone"), default="auto",
                        help="audio source selection")
    parser.add_argument("--device", help="ALSA card number or text to match")
    parser.add_argument("--diagnostics-dir", default=DIAG_DIR)
    parser.add_argument("--record-seconds", type=int, default=15)
    parser.add_argument("--no-record", action="store_true")
    parser.add_argument("--sync-time", action="store_true", help="enable system NTP synchronization")
    parser.add_argument("--ntp-server", default="pool.ntp.org")
    return parser.parse_args()


def main():
    args = parse_args()
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))
    try:
        curses.wrapper(main_screen, args)
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
